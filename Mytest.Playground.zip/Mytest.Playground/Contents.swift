var todo: [String] = ["Finish collection course", "Buy groceries", "game"]
var numbers = [1,2,23]

//adding to an array
todo.append("code")

// concatenating two arrays
[1,2,3] + [4]
todo += ["order cracking the coding interview"]

// reading from arrays
todo[0]
let myFirstTask = todo[0]
let myThirdTask = todo[3]

//modifying Exisiting values in an array
todo[3]
todo[3] = "fix Xcode"
todo

// Insert using Indexes
todo.insert("watch tv", at: 2)
todo

// Removing items from arrays
todo.remove(at: 3)
todo


todo.count
todo[4]
// todo[5] index number to high
let house = 281
print(house)

let scoreValue = 567
if scoreValue >= 99 {
    print("Loser")
} else {
    print("Winner")
}
